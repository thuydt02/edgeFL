from tqdm import tqdm

import torch

import numpy as np
import random
from torchvision import transforms
from torch.utils.data import TensorDataset, DataLoader, ConcatDataset

from datasets import MNIST_truncated, CIFAR10_truncated, CIFAR100_truncated, SVHN_custom, FashionMNIST_truncated, CustomTensorDataset, CelebA_custom, FEMNIST, Generated, genData


#run in gg colab
data_DIR = "/content/drive/MyDrive/eFL/data/"

data_DIR = "../../data" # run local

def load_femnist_data(datadir):
    transform = transforms.Compose([transforms.ToTensor()])

    mnist_train_ds = FEMNIST(datadir, train=True, transform=transform, download=True)
    mnist_test_ds = FEMNIST(datadir, train=False, transform=transform, download=True)

    X_train, y_train, u_train = mnist_train_ds.data, mnist_train_ds.target, mnist_train_ds.users_index
    X_test, y_test, u_test = mnist_test_ds.data, mnist_test_ds.target, mnist_test_ds.users_index

    X_train = X_train.data.numpy()
    y_train = y_train.data.numpy()
    u_train = np.array(u_train)
    X_test = X_test.data.numpy()
    y_test = y_test.data.numpy()
    u_test = np.array(u_test)

    return (X_train, y_train, u_train, X_test, y_test, u_test)

X_train, y_train, u_train, X_test, y_test, u_test = load_femnist_data(data_DIR)

print ("X_train.shape, y_train.shape, u_train.shap: ", X_train.shape, y_train.shape, u_train.shape)

print ("X_test.shape, y_test.shape, u_test.shap: ", X_test.shape, y_test.shape, u_test.shape)

print ("(min, max) of u_train, u_test: ", (np.min(u_train), np.max(u_train)), (np.min(u_test), np.max(u_test)))

print("u_train", u_train[:10])
