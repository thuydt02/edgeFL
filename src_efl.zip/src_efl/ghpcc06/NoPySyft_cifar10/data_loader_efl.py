from tqdm import tqdm

import torch

import numpy as np
from torchvision import datasets, transforms
from torch.utils.data import TensorDataset, DataLoader, ConcatDataset

#run in gg colab
#data_DIR = "/content/drive/MyDrive/NA-Multiple-Edge-Servers-Federated-Learning/data/"
data_DIR = "../../data" # run local
class MNISTDataLoader:
	def __init__(self, batch_size):
		self.train_data = self.load_data(train=True)
		self.test_data = DataLoader(self.load_data(train=False), batch_size=batch_size, shuffle=True)
		self.batch_size = batch_size
		#print("checking")
		#print(self.train_data.data[0:3])
		#exit()
		return
	
	
	def load_data(self, train):
	    from six.moves import urllib
	    opener = urllib.request.build_opener()
	    opener.addheaders = [('User-agent', 'Mozilla/5.0')]
	    urllib.request.install_opener(opener)
	    transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
	    data = datasets.MNIST(data_DIR, train=train, download=True, transform=transform)
	    return data


	def normalize(self, x, mean=0.1307, std=0.3081):
		return (x-mean)/std


	def prepare_iid_data(self, no_clients):
		clients_data = {}
		data = self.train_data

		images = self.normalize(data.data).unsqueeze(1)
		labels = data.targets

		return self.distribute_in_shards(images, labels, no_clients)
		

	def prepare_non_iid_data_option1(self, no_clients):
		'''
		Follow original FL paper
		Sort the data by digit label
		Divide it into 200 shards of size 300
		Assign each of n clients 200/n shards
		'''

		data = self.train_data
		
		sorted_images = []
		sorted_labels = []

		for number in range(10):
			indices = (data.targets == number).int()

			images = data.data[indices == 1]
			labels = data.targets[indices == 1]

			images = self.normalize(images).unsqueeze(1)

			sorted_images += images.unsqueeze(0)
			sorted_labels += labels.unsqueeze(0)

		sorted_images = torch.cat(sorted_images)
		sorted_labels = torch.cat(sorted_labels)

		
		return self.distribute_in_shards(sorted_images, sorted_labels, no_clients)

	def prepare_non_iid_data_option_zipf(self, no_clients, zipfz):

		data = self.train_data
		
		sorted_images = []
		sorted_labels = []
		
		num_label = np.zeros(10)


		for number in range(10):
			indices = (data.targets == number).int()

			images = data.data[indices == 1]
			labels = data.targets[indices == 1]

			images = self.normalize(images).unsqueeze(1)

			sorted_images += images.unsqueeze(0)
			sorted_labels += labels.unsqueeze(0)

			num_label[number] = len(images)
			#print("label, num_sample: ", number, " ", num_label[number])


		sorted_images = torch.cat(sorted_images)
		sorted_labels = torch.cat(sorted_labels)

		#exit()
		p = self.draw_zipf_distribution (no_clients, zipfz)
		return self.distribute_in_batches(sorted_images, sorted_labels, no_clients, p)



	def distribute_in_shards(self, images, labels, no_clients):
		shards = []
		for i in range(200):
			start = i*300
			end = start + 300

			shard_images = images[start:end]
			shard_labels = labels[start:end]

			shard = TensorDataset(shard_images, shard_labels)
			shards.append(shard)

		clients_data = {}
		
		shards_per_client = len(shards)/no_clients
		for shard_idx, shard in enumerate(shards):
			receiving_client = (int)(shard_idx//shards_per_client)
			if receiving_client not in clients_data:
				clients_data[receiving_client] = [shard]
			else:
				clients_data[receiving_client].append(shard)
			

		for client_number, client_data in clients_data.items():
			clients_data[client_number] = DataLoader(ConcatDataset(client_data), shuffle=True, batch_size=self.batch_size)

		return clients_data
	
	
	def distribute_in_batches(self, images, labels, no_clients, p):
		
		num_batch = int(len(images) /self.batch_size)
		client_num_batch = []
		#dominator_sum = sum(range(1:no_clients+1))

		"""for i in range(no_clients):
			tmp = int(num_batch * (1+i)/ dominator_sum)
			num_batch_assigned += tmp
			client_num_batch.append(tmp)

		client_num_batch[0] += client_num_batch - num_batch_assigned
		"""
		batches = []

		for i in range(num_batch):
			start = i * self.batch_size
			end = start + self.batch_size

			batch_images = images[start:end]
			batch_labels = labels[start:end]

			batch = TensorDataset(batch_images, batch_labels)
			batches.append(batch)
		#print("num_batch, ", num_batch)
		#print("sum_p: ", sum(p))
		#print("p: ", p)
		#print("num_batches: ", len(batches))

		clients_data = {}
		
		start = 0
		for i in range(no_clients):
			end = start + int(p[i] * num_batch)

			#print("client, start, end: ", i, ", ", start, ", ", end)
			clients_data[i] = batches[start:end]
			start = end

		if start < num_batch:
			clients_data[0] += batches[start: num_batch]

		for client_number, client_data in clients_data.items():
			clients_data[client_number] = DataLoader(ConcatDataset(client_data), shuffle=True, batch_size=self.batch_size)

		return clients_data

	def draw_zipf_distribution(self, no_clients, z):
		
		p = (1/np.arange(1,no_clients + 1))**(z)
		return p/sum(p)



"""
label, num_sample:  0   5923.0
label, num_sample:  1   6742.0
label, num_sample:  2   5958.0
label, num_sample:  3   6131.0
label, num_sample:  4   5842.0
label, num_sample:  5   5421.0
label, num_sample:  6   5918.0
label, num_sample:  7   6265.0
label, num_sample:  8   5851.0
label, num_sample:  9   5949.0
"""






