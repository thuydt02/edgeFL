from tqdm import tqdm

import torch

import numpy as np
import random
from torchvision import transforms
from torch.utils.data import TensorDataset, DataLoader, ConcatDataset

from datasets import MNIST_truncated, CIFAR10_truncated, CIFAR100_truncated, SVHN_custom, FashionMNIST_truncated, CustomTensorDataset, CelebA_custom, FEMNIST, Generated, genData
from PIL.Image import BICUBIC
from torchvision.transforms import Compose, RandomCrop, Pad, RandomHorizontalFlip, Resize
from torchvision.transforms import ToTensor, Normalize


#run in gg colab
data_DIR = "/content/drive/MyDrive/eFL/data/"
#data_DIR = "../../data" # run local

class Data_Loader_EfficientNet_Cifar100:
	def __init__(self, batch_size):
		train_transform = Compose([
			Resize(256, BICUBIC),
			RandomCrop(224),
			RandomHorizontalFlip(),
			ToTensor(),
			Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

		test_transform = Compose([
			Resize(224, BICUBIC),    
			ToTensor(),
			Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

		self.batch_size = batch_size

		
		self.train_data = self.load_data(train=True, transform = train_transform)
		self.test_data = self.load_test(transform = test_transform)#DataLoader(dataset=self.load_data(train = False, transform = transform), batch_size=self.batch_size, shuffle=True, drop_last=False)
	
	def load_test(self, transform):
		test_data = self.load_data(train=False, transform = transform)
		x_test = test_data.data
		y_test = test_data.target

		num_batch = int(len(x_test) / self.batch_size)
		
		#x_test = self.normalize(x_test)
		batches = []
		#print("xtest.shape: ", x_test.shape)
		#print("ytest.shape: ", y_test.shape)

		
		for i in range(num_batch):
			start = i * self.batch_size
			end = start + self.batch_size

			batch = TensorDataset(x_test[start:end], y_test[start:end])
			batches.append(batch)
		
		if end < len(x_test):
			batches.append(TensorDataset(x_test[end:len(x_test)], y_test[end:len(y_test)]))
		return DataLoader(ConcatDataset(batches), shuffle=True, batch_size=self.batch_size)
		#return DataLoader(TensorDataset(x_test, y_test), shuffle=True, batch_size=self.batch_size, drop_last = False)
	
	def load_data(self, train, transform):
		cifa100 = CIFAR100_truncated(data_DIR, train=train, transform=transform, download=True)
		return cifa100

	def prepare_in_batch_given_partition(self, num_clients, partition_file):

		images = self.train_data.data
		labels = self.train_data.target
		#images = self.normalize(images).unsqueeze(1)
		
		partition_list = []
		clients_data = {}


		with open(partition_file, 'rb') as f:
			for cl in range(num_clients):		
				partition_list.append(np.load(f))
			
		for cl in range(num_clients):
			clients_data[cl] = []

		
		for cl in range(num_clients):
			start = 0
			num_img_taken = 0

			#print("client ", cl, ": ", len(partition_list[cl]))
			#exit()

			while num_img_taken < len(partition_list[cl]):
				if num_img_taken + self.batch_size <= len(partition_list[cl]):
					end = start + self.batch_size
					num_img_taken += self.batch_size
				else:
					end = start + len(partition_list[cl]) - num_img_taken
					num_img_taken = len(partition_list[cl])


				img_indices = partition_list[cl][start:end]
				batch_img = images[img_indices]
				
				batch_label = labels[img_indices]


				#print("shape of img and labels: ")
				#print(batch_img.shape)
				#print(batch_label.shape, " ", batch_label)
				#print(batch_img)

				batch = TensorDataset(batch_img, batch_label)
				clients_data[cl].append(batch)

				start = end
			#print("cl ", cl, " num_batches: ", len(clients_data[cl]))
		#s = 0
		for client_number, client_data in clients_data.items():
		#	s += len(client_data)
			clients_data[client_number] = DataLoader(ConcatDataset(client_data), shuffle=True, batch_size=self.batch_size)

		#print("num_batches: ", s)
		#exit()
		return clients_data





